# Tarea post-taller: crear modelo para comentarios

Actualmente sólo tenemos un modelo *Post*. ¿No sería una buena idea dejar a los lectores comentar nuestros posts?

## Crear el modelo de comentario

Vamos a abrir `blog/models.py` y agregar el siguiente código al final del archivo:

```python
class Comment(models.Model):
    post = models.ForeignKey('blog.Post', related_name='comments')
    author = models.CharField(max_length=200)
    text = models.TextField()
    created_date = models.DateTimeField(default=timezone.now)
    approved_comment = models.BooleanField(default=False)

    def approve(self):
        self.approved_comment = True
        self.save()

    def __str__(self):
        return self.text
```

Puedes volver al capítulo **Modelos en Django** en el tutorial si necesitas repasar lo que significan cada uno de los tipos de campo.

En esta extensión del tutorial tenemos un nuevo tipo de campo: 
- `models.BooleanField` - este campo puede tener los valores true/false (verdadero o falso).
 
La opción `related_name` que vemos en `models.ForeignKey` nos permite tener acceso a los comentario desde el modelo Post.

## Crear tablas para los modelos en la base de datos

Ahora vamos a agregar nuestro modelo de comentario (*Comment*) a la base de datos.  Para hacer esto le tenemos que decir a Django que hicimos cambios en nuestro modelo original. Escribimos `python manage.py makemigrations blog` en la consola. El resultado debe ser:

    (myvenv) ~/djangogirls$ python manage.py makemigrations blog
    Migrations for 'blog':
      0002_comment.py:
        - Create model Comment

Como puedes ver, este comando creó otro archivo de migración por nosotras en el directorio `blog/migrations/`. Ahora necesitamos aplicar esos cambios escribiendo `python manage.py migrate blog` en la consola. El resultado debe ser:

```
    (myvenv) ~/djangogirls$ python manage.py migrate blog
    Operations to perform:
      Apply all migrations: blog
    Running migrations:
      Rendering model states... DONE
      Applying blog.0002_comment... OK
```

¡Ahora nuestro modelo Comment existe en la base de datos! ¿No sería genial si lo pudiéramos acceder desde nuestro panel de administración?

## Registrar el modelo Comment en el panel de administración

Para registrar el modelo Comment en el panel de administración, vamos a `blog/admin.py`y agregamos la siguiente línea: 

```python
admin.site.register(Comment)
```

Justo debajo de esta otra línea:

```python
admin.site.register(Post)
```

Recuerda también de importar el modelo Comment al principio del archivo, de esta forma:

```python
from django.contrib import admin
from .models import Post, Comment

admin.site.register(Post)
admin.site.register(Comment)
```
Si ejecutas `python manage.py runserver` en la consola y vas a [http://127.0.0.1:8000/admin/](http://127.0.0.1:8000/admin/) en el navegador, deberías tener acceso a la lista de comentarios y, también, la posibilidad de agregar y eliminar comentarios. ¡Juega con esto un rato y mira lo que puedes hacer! 

## Hacer los comentarios visibles

Vamos ahora al archivo `blog/templates/blog/post_detail.html` y agrega las siguientes líneas antes de la etiqueta `{% endblock %}`:

```django
<hr>
{% for comment in post.comments.all %}
    <div class="comment">
        <div class="date">{{ comment.created_date }}</div>
        <strong>{{ comment.author }}</strong>
        <p>{{ comment.text|linebreaks }}</p>
    </div>
{% empty %}
    <p>No comments here yet :(</p>
{% endfor %}
```

Ahora podemos ver la sección de comentarios en las páginas de detalles del post.

Pero podría verse un poco mejor, ¿no? Así que agreguemos algo de CSS al final del archivo `static/css/blog.css`:

```css
.comment {
    margin: 20px 0px 20px 20px;
}
```

También podríamos hacer saber a nuestros visitantes de la existencia de comentarios en la página que lista los posts. Vamos al archivo `blog/templates/blog/post_list.html` y agregamos la siguiente línea: 

```django
<a href="{% url 'post_detail' pk=post.pk %}">Comments: {{ post.comments.count }}</a>
```

Luego de esto nuestra plantilla debería verse así:

```django
{% extends 'blog/base.html' %}

{% block content %}
    {% for post in posts %}
        <div class="post">
            <div class="date">
                {{ post.published_date }}
            </div>
            <h1><a href="{% url 'post_detail' pk=post.pk %}">{{ post.title }}</a></h1>
            <p>{{ post.text|linebreaksbr }}</p>
            <a href="{% url 'post_detail' pk=post.pk %}">Comments: {{ post.comments.count }}</a>
        </div>
    {% endfor %}
{% endblock content %}
```

## Permitir a nuestros lectores escribir comentarios

Hasta este momento podemos ver los comentarios en nuestro blog, pero no podemos agregar nuevos. ¡Cambiemos eso!

Vamos al archivo `blog/forms.py` y agregamos las siguientes líneas al final:

```python
class CommentForm(forms.ModelForm):

    class Meta:
        model = Comment
        fields = ('author', 'text',)
```

Recuerda importar el modelo Comment cambiando la línea:

```python
from .models import Post
```

Por esta otra:

```python
from .models import Post, Comment
```

Ahora vamos al archivo `blog/templates/blog/post_detail.html` y antes de la línea `{% for comment in post.comments.all %}`, agregamos:

```django
<a class="btn btn-default" href="{% url 'add_comment_to_post' pk=post.pk %}">Add comment</a>
```

Si ahora vamos a la página de detalle del post veremos este error:

![NoReverseMatch](images/url_error.png)

¡Sabemos cómo solucionarlo! Vamos al archivo `blog/urls.py` y agregamos este patrón a `urlpatterns`:

```python
url(r'^post/(?P<pk>\d+)/comment/$', views.add_comment_to_post, name='add_comment_to_post'),
```


Refrescamos la página y... ¡tenemos un error distinto!  

![AttributeError](images/views_error.png)

Para solucionar este error agregamos esta view al archivo `blog/views.py`:

```python
def add_comment_to_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = CommentForm()
    return render(request, 'blog/add_comment_to_post.html', {'form': form})
```

Recuerda importar `CommentForm` al principio del archivo:

```python
from .forms import PostForm, CommentForm
```

Ahora en la página de detalle del post deberías ver el botón "Add Comment". 

![AddComment](images/add_comment_button.png)

Pero si haces clic en el botón verás:

![TemplateDoesNotExist](images/template_error.png)

Tal cual nos dice el error, la plantilla aún no existe. Así que crea una nueva en `blog/templates/blog/add_comment_to_post.html` y agrega el siguiente código.

```django
{% extends 'blog/base.html' %}

{% block content %}
    <h1>New comment</h1>
    <form method="POST" class="post-form">{% csrf_token %}
        {{ form.as_p }}
        <button type="submit" class="save btn btn-default">Send</button>
    </form>
{% endblock %}
```

¡Yay! ¡Ahora tus lectores te podrán decir lo que piensan de tus posts!

## Moderando los comentarios

No es necesario que todos los comentarios sean visibles. Cómo dueña del blog quizás quieras la opción de aprobar o eliminar comentarios. Hagamos algo al respecto.

Ve a `blog/templates/blog/post_detail.html` y cambia estas líneas:

```django
{% for comment in post.comments.all %}
    <div class="comment">
        <div class="date">{{ comment.created_date }}</div>
        <strong>{{ comment.author }}</strong>
        <p>{{ comment.text|linebreaks }}</p>
    </div>
{% empty %}
    <p>No comments here yet :(</p>
{% endfor %}
```

por estás otras:

```django
{% for comment in post.comments.all %}
    {% if user.is_authenticated or comment.approved_comment %}
    <div class="comment">
        <div class="date">
            {{ comment.created_date }}
            {% if not comment.approved_comment %}
                <a class="btn btn-default" href="{% url 'comment_remove' pk=comment.pk %}"><span class="glyphicon glyphicon-remove"></span></a>
                <a class="btn btn-default" href="{% url 'comment_approve' pk=comment.pk %}"><span class="glyphicon glyphicon-ok"></span></a>
            {% endif %}
        </div>
        <strong>{{ comment.author }}</strong>
        <p>{{ comment.text|linebreaks }}</p>
    </div>
    {% endif %}
{% empty %}
    <p>No comments here yet :(</p>
{% endfor %}
```

Deberías ver el error de `NoReverseMatch`, ya que ninguna URL coincide con los patrones de `comment_remove` y `comment_approve` ¡Hasta ahora!

Para solucionar el error agrega estos patrones de URL en `blog/urls.py`:

```python
url(r'^comment/(?P<pk>\d+)/approve/$', views.comment_approve, name='comment_approve'),
url(r'^comment/(?P<pk>\d+)/remove/$', views.comment_remove, name='comment_remove'),
```

Ahora deberías ver el error `AttributeError`. Para solucionarlo agrega estas vistas en el archivo `blog/views.py`:

```python
@login_required
def comment_approve(request, pk):
    comment = get_object_or_404(Comment, pk=pk)
    comment.approve()
    return redirect('post_detail', pk=comment.post.pk)

@login_required
def comment_remove(request, pk):
    comment = get_object_or_404(Comment, pk=pk)
    post_pk = comment.post.pk
    comment.delete()
    return redirect('post_detail', pk=post_pk)
```

Recuerda de importar `Comment` al principio del archivo:

```python
from .models import Post, Comment
```

¡Todo funciona! Hay un pequeño ajuste que podemos hacer: En la página que lista los posts - debajo de los post - se está mostrando el número de todos los comentarios que este ha recibido. Cambiemos eso para mostrar allí el número de comentarios *aprobados*.

Para solucionar esto ve a `blog/templates/blog/post_list.html` y cambia la siguiente línea:

```django
<a href="{% url 'post_detail' pk=post.pk %}">Comments: {{ post.comments.count }}</a>
```

por esta otra:

```django
<a href="{% url 'post_detail' pk=post.pk %}">Comments: {{ post.approved_comments.count }}</a>
```

Finalmente agrega este método al modelo Post en `blog/models.py`:

```python
def approved_comments(self):
    return self.comments.filter(approved_comment=True)
```

¡Tu blog ahora ya puede recibir comentarios! ¡Felicitaciones! :-)