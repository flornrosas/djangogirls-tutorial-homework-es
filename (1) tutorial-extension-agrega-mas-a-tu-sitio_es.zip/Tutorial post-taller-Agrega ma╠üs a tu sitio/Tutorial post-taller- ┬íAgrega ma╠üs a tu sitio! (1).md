# Tutorial post-taller: ¡Agrega más a tu sitio!

---

Nuestro blog nos ha tomado bastante tiempo, pero aún queda mucho por hacer y mejorar. ¡Así que seguimos! Ahora, agregaremos algunas características a los borradores de las entradas y su publicación. También aprenderás a eliminar las publicaciones que no deseamos que estén ahí. ¡En Marcha!

### Guarda las publicaciones del blog como borradores

Actualmente, cuando estamos creando nuevas publicaciones utilizando nuestro formulario “Nuevo post”, la cual sube la publicación a internet directamente. Para guardarla como borrador, borra esta línea en `blog/views.py` en los métodos `post_new` y `post_edit`:

```python
post.published_date = timezone.now()
```

De esta forma, los nuevos mensajes se guardarán como borradores que podremos revisar posteriormente en lugar de publicarlos inmediatamente. Todo lo que necesitamos ahora es una forma de listar y publicar borradores, ¡vamos allá!

### Página con lista de publicaciones sin subir

¿Recuerdas el capítulo acerca de los Querysets? Allí creamos una vista `post_list` que muestra sólo publicaciones subidas (aquellas con `public_date` no vacías).

Es hora de hacer algo similar, pero para publicaciones de borrador.
Vamos a agregar un enlace en `blog/templates/blog/base.html`  en el encabezado. No queremos mostrar nuestra lista de borradores a todos, por lo que lo pondremos dentro del `{% if user.is_authenticated %}`, justo después del botón de agregar nuevo post.

```python
<a href="{% url 'post_draft_list' %}" class="top-menu"><span class="glyphicon glyphicon-edit"></span></a>
```

Siguiente: URLS! En `blog/urls.py agregamos`:

```python
url(r'^drafts/$', views.post_draft_list, name='post_draft_list'),
```

Es tiempo de crear una vista en `blog/views.py`:

```python
def post_draft_list(request):
    posts = Post.objects.filter(published_date__isnull=True).order_by('created_date')
    return render(request, 'blog/post_draft_list.html', {'posts': posts})
```

La línea `posts = Post.objects.filter(publish_date__insull=True).order_by('created_date')` te asegura que nos referiremos sólo a las publicaciones que aún no hayas publicado `(published_date__isnull=True)` y los ordena con el `created_date (order_by('created_date'))`.

Ok, para lo ultimo que queda es por su puesto una plantilla! Crea un archivo `blog/templates/blog/post_draft_list.html` y agrega lo siguiente:

```python
{% extends 'blog/base.html' %}

{% block content %}
    {% for post in posts %}
        <div class="post">
            <p class="date">created: {{ post.created_date|date:'d-m-Y' }}</p>
            <h1><a href="{% url 'post_detail' pk=post.pk %}">{{ post.title }}</a></h1>
            <p>{{ post.text|truncatechars:200 }}</p>
        </div>
    {% endfor %}
{% endblock %}
```

Se ve similar al archivo post_list.html, no?
Ahora cuando vayamos a http://127.0.0.1:8000/drafts/ verás la lista de las publicaciones que aún no has publicado.
Yay! Tu primera tarea está terminada!

### Agrega un botón para publicar
Sería agradable tener un botón en el blog que publique el post directamente, no?
Abramos `blog/template/blog/post_detail.html` y cambiemos estas líneas:

```python
{% if post.published_date %}
    <div class="date">
        {{ post.published_date }}
    </div>
{% endif %}
into these:
{% if post.published_date %}
    <div class="date">
        {{ post.published_date }}
    </div>
{% else %}
    <a class="btn btn-default" href="{% url 'post_publish' pk=post.pk %}">Publish</a>
{% endif %}
```

Como habrás notado, agregamos una línea `{% else %}`. Lo que significa que la condición {% if post.published_date %} no se cumplirá si no hay un `published_date`,
entonces tuvimos que poner la linea `<a class="btn btn-default" href="{% url 'post_publish' pk=post.pk %}">Publish</a>` 

Nota que estamos pasando una variable pk en el `{% url %}`.
Es tiempo de creat una URL (en ````pythonblog/urls.py`):

```python
url(r'^post/(?P<pk>\d+)/publish/$', views.post_publish, name='post_publish'),
```

y finalmente, una vista (como siempre en blog/views.py):

```python
def post_publish(request, pk):
    post = get_object_or_404(Post, pk=pk)
    post.publish()
    return redirect('post_detail', pk=pk)
```

Recuerda, cuando creamos un modelo Post escribimos un método público. Se verá así:

```python
def publish(self):
    self.published_date = timezone.now()
    self.save()
```

¡Ahora podemos probarlo!
Una vez más después de publicar el post somos redirigidos inmediatamente a la página de post_detail!

![Imagen1](images/img1.png)

¡Felicitaciones! Ya casi terminamos. El ultimo paso es agregar un botón para borrar.

### Borrar Publicación

Abramos el fichero blog/templates/blog/post_detail.html una vez mas y agreguemos esta línea:

```python
<a class="btn btn-default" href="{% url 'post_remove' pk=post.pk %}"><span class="glyphicon glyphicon-remove"></span></a>
```

debajo de una linea con la edición de botón.

Ahora necesitamos una URL (blog/urls.py):

```python
url(r'^post/(?P<pk>\d+)/remove/$', views.post_remove, name='post_remove'),
```

Ahora, es tiempo de verlo! Abre blog/views.py y agrega este código:

```python
def post_remove(request, pk):
    post = get_object_or_404(Post, pk=pk)
    post.delete()
    return redirect('post_list')
```

Lo unico que queda hacer es borrar algún post del blog. Cada modelo Django puede ser borrado con .delete(). Es tan simple como eso!

Esta vez, después de borrar el post seguramente queremos ir al sitio web con la lista de las publicaciones, entonces allí debemos usar un redirect.

Vamos a testearlo! Ve a la página con un post y bórralo!

![Imagen2](images/img2.png)

Si, eso es lo último! Completaste este tutorial! Eres genial!