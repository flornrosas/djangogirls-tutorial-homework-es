# Agregando seguridad a nuestro sitio web
----

Quizás has notado que no has tenido que utilizar tu password cuando ingresas como administrador. Quizás tambien hayas notado que eso significa que cualquier persona puede agregar o editar posts en tu blog. No se tu, pero yo no quisiera que alguien que no conozco publique en mi página. Por eso hagamos algo para evitarlo.

## Autorizando adición/edición de publicaciones

Primero hagamos que las cosas sean seguras. Vamos a proteger nuestras vistas `post_new`, `post_edit`, `pot_draft_list`, `post_remove` y `post_publish` para que sólo los usuarios registrados puedan acceder a ellos. Django cuenta con unos simpáticos ayudantes para ello, llamados _ decorators _. No te preocupes por los tecnisismos ahora; puedes investigar sobre ellos después. El decorador que queremos usar aparece en Django en el módulo `django.contrib.auth.decorators` y se llama `login_required`.

Así que edita tu `blog/views.py` agregando estas lineas al principio con el resto de las importaciones:

```python
from django.contrib.auth.decorators import login_required
```

Después agraga una línea al principio de las vistas `post_new`, `post_edit`, `post_draft_list`, `post_remove` and `post_publish` (las estamos decorando). Se verá así:

```python
@login_required
def post_new(request):
    [...]
```

Eso es todo! Ahora intenta acceder `http://localhost:8000/post/new/`. Notas la diferencia?

> Si tienes sólo el formulario vacío,  probablemente estés loggeada desde la página del administrador. Dirígete a `http://localhost:8000/admin/logout/` para cerrar la sesión, después puedes ingresar a `http://localhost:8000/post/new` de nuevo.

Ahora debería aparecer un error que seguramente ya has visto y quizás te hayas hasta encariñado con el. Fíjate qué interesante: el decorador que agregamos nos va a redirigir a la página para iniciar sesión o "hacer log in", pero como aún no está disponible, mostrará un "Error 404: Page not found".

No olvides agregar el decorador a los ficheros `post_edit`, `post_remove`, `post_draft_list` y `post_publish` también.

Muy bien! Hemos alcanzado el objetivo del tutorial!! Ahora  otras personas no podrán crear publicaciones en nuestro blog, a menos que estén registradas. Desafortunadamente nosotros tampoco podemos crear publicaciones :( ¿Qué tal si arreglamos eso?

## Log in o inicio de sesión de usuarios

Ahora podríamos intentar hacer un montón de mágia para implementar autenticación de usuarios y contraseñas, pero hacero de la forma correcta es algo complicado. Como Django siempre está "con las pilas puestas", alguien hizo el trabajo duro por nosotras, entonces usaremos sus herramientas para realizar la autenticación.

En tu `mysite/urls.py` agrega una url `url(r'^accounts/login/$', views.login)`. Ahora el contenido debería ser similar a este:

```python
from django.conf.urls import include, url
from django.contrib import admin

from django.contrib.auth import views

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^accounts/login/$', views.login, name='login'),
    url(r'', include('blog.urls')),
]
```

Después necesitaremos una plantilla para la página de inicio de sesión, entonces crearemos un directorio `blog/templates/registration` y un archivo dentro llamado `login.html`:

```django
{% extends "blog/base.html" %}

{% block content %}
    {% if form.errors %}
        <p>Your username and password didn't match. Please try again.</p>
    {% endif %}

    <form method="post" action="{% url 'login' %}">
    {% csrf_token %}
        <table>
        <tr>
            <td>{{ form.username.label_tag }}</td>
            <td>{{ form.username }}</td>
        </tr>
        <tr>
            <td>{{ form.password.label_tag }}</td>
            <td>{{ form.password }}</td>
        </tr>
        </table>

        <input type="submit" value="login" />
        <input type="hidden" name="next" value="{{ next }}" />
    </form>
{% endblock %}
```

Verás también que hace uso de nuestra plantilla _ base_ para conservar el aspecto general de nuestro blog.

Lo bueno de esto es que así funciona. No tenemos que lidiar con el manejo de un formulario con contraseñas y luego hacerlos seguros. Sólo una cosa más queda por hacer. Debemos agregar un ajuste al archivo `mysite/settings.py`:

```python
LOGIN_REDIRECT_URL = '/'
```

Entonces cuando accedas a la página de inicio de sesión directamente, serás redirigida a un inicio de sesión en un nivel superior (la página principal de nuestro blog).

## Mejorando el diseño

Ahora ya nos aseguramos que sólo los usuarios autorizados (por ejemplo, nosotras) puedan agregar, editar o publicar posts. Pero todo el mundo sigue viendo los botones para agregar o editar publicaciones. Escondamos esto para los usuarios que no hayan iniciado sesión. Para esto necesitamos editar las plantillas, así que empecemos con la plantilla base en el archivo `blog/templates/blog/base.html`:

```django
<body>
    <div class="page-header">
        {% if user.is_authenticated %}
            <a href="{% url 'post_new' %}" class="top-menu"><span class="glyphicon glyphicon-plus"></span></a>
            <a href="{% url 'post_draft_list' %}" class="top-menu"><span class="glyphicon glyphicon-edit"></span></a>
        {% else %}
            <a href="{% url 'login' %}" class="top-menu"><span class="glyphicon glyphicon-lock"></span></a>
        {% endif %}
        <h1><a href="/">Django Girls Blog</a></h1>
    </div>
    <div class="content container">
        <div class="row">
            <div class="col-md-8">
            {% block content %}
            {% endblock %}
            </div>
        </div>
    </div>
</body>
```

Seguro puedes reconocer el patrón aquí. Hay una condición if en la plantilla que comprueba que a los usuarios autenticados les sean mostrados los botones de agregar y editar. De lo contrario, muestra un botón de inicio de sesión.

**Tarea**: Edita la plantilla `blog/templates/blog/post_detail.html` para que solamente muestre los botones de agregar y editar a los usuarios autenticados.

## Más sobre usuarios autenticados.

Le vamos a poner un poco de azúcar a nuestras plantillas. Primero agregaremos algunos detalles para mostrar cuando hayamos iniciado sesión. Edita el archivo `blog/templates/blog/base.html` de esta forma:

```django
<div class="page-header">
    {% if user.is_authenticated %}
        <a href="{% url 'post_new' %}" class="top-menu"><span class="glyphicon glyphicon-plus"></span></a>
        <a href="{% url 'post_draft_list' %}" class="top-menu"><span class="glyphicon glyphicon-edit"></span></a>
        <p class="top-menu">Hello {{ user.username }} <small>(<a href="{% url 'logout' %}">Log out</a>)</small></p>
    {% else %}
        <a href="{% url 'login' %}" class="top-menu"><span class="glyphicon glyphicon-lock"></span></a>
    {% endif %}
    <h1><a href="/">Django Girls Blog</a></h1>
</div>
```

Esto agrega un simpático "Hello _&lt;NombreDeUsuario&gt;_" para recordarnos que hemos iniciado sesión y estamos autenticados. Además, agrega un link para cerrar la sesión del blog -- pero como ya habrás notado, todavía no funciona. ¡Vamos a solucionarlo!

Decidimos confiar en Django para manejar el inicio de sesión, así que veamos si Django también puede manejar el cierre de sesión por nosotros. Ve a  https://docs.djangoproject.com/en/1.10/topics/auth/default/ y fijate si puedes encontrar algo.

¿Terminaste de leer? A estas alturas, es posible que estés pensando en añadir una URL en `mysite / urls.py` apuntando a la vista de cierre de sesión de Django (es decir, `django.contrib.auth.views.logout`), de la siguiente forma:

```python
from django.conf.urls import include, url
from django.contrib import admin

from django.contrib.auth import views

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^accounts/login/$', views.login, name='login'),
    url(r'^accounts/logout/$', views.logout, name='logout', kwargs={'next_page': '/'}),
    url(r'', include('blog.urls')),
]
```

¡Eso es! Si seguiste todo lo anterior hasta este punto (e hiciste tu tarea), ahora tiene un blog donde:

  - necesitas un nombre de usuario y contraseña para iniciar sesión,
  - necesitas estar autenticado para agregar, editar, publicar o eliminar mensajes,
  - y puedes cerrar cesión.
 
